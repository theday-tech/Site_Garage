var logo=document.querySelector('.container');
var menu = document.querySelector('.menu');

logo.addEventListener('click', function(){
    menu.classList.toggle('showmenu')
});